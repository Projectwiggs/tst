
/**
 *Name: Cole Gimpy
 *Date: 02.01.2016
 *Desc: GUI Car Purchase
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static java.lang.Math.*;

public class Car extends JFrame
{
   private JLabel headerL, logoL, oneL, twoL, valueL;
   private JTextField oneTF, twoTF, valueTF;
   private JButton addB, subtractB, divideB, multiplyB, exitB;
   
   private AddButtonHandler cbHandler;
   private SubtractButtonHandler sbHandler;
   private MultiplyButtonHandler mbHandler;
   private DivideButtonHandler dbHandler;
   private ExitButtonHandler ebHandler;
   
   private static final int WIDTH = 400;
   private static final int HEIGHT = 300;
   
   public Car()
   {
   //create labels
   headerL = new JLabel("Calculator TI-85 ", SwingConstants.RIGHT);
   BullsEye panel = new BullsEye();
   oneL = new JLabel("Enter in first value: ", SwingConstants.RIGHT);
   twoL = new JLabel("Enter in second value: ", SwingConstants.RIGHT);
   valueL = new JLabel("Total value: ", SwingConstants.RIGHT);
   
   //create textfields
   oneTF = new JTextField(10);
   twoTF = new JTextField(10);
   valueTF = new JTextField(10);
   
   //create button
   addB = new JButton("+");
   cbHandler = new AddButtonHandler();
   addB.addActionListener(cbHandler);
   
   subtractB = new JButton("-");
   sbHandler = new SubtractButtonHandler();
   subtractB.addActionListener(sbHandler);
   
   multiplyB = new JButton("*");
   mbHandler = new MultiplyButtonHandler();
   multiplyB.addActionListener(mbHandler);
   
   divideB = new JButton("/");
   dbHandler = new DivideButtonHandler();
   divideB.addActionListener(dbHandler);
   
   exitB = new JButton("Exit");
   ebHandler = new ExitButtonHandler();
   exitB.addActionListener(cbHandler);
   
   //Window Title
   setTitle("Dis be duh best calculator");
   
   //get the container
   Container pane = getContentPane();
   
   //set layout
   pane.setLayout(new GridLayout(7, 2));
   
   //place components in the pane
   pane.add(headerL);
   pane.add(panel);
   pane.add(oneL);
   pane.add(oneTF);
   pane.add(twoL);
   pane.add(twoTF);
   pane.add(valueL);
   pane.add(valueTF);
   pane.add(addB);
   pane.add(subtractB);
   pane.add(multiplyB);
   pane.add(divideB);
   pane.add(exitB);
   
   //set the size of the window and display it
   setSize(WIDTH, HEIGHT);
   setVisible(true);
   
   setDefaultCloseOperation(EXIT_ON_CLOSE);
}

private class AddButtonHandler implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {
        double one, two, value;
        
        one = Double.parseDouble(oneTF.getText());
        two = Double.parseDouble(twoTF.getText());
        value = one + two;
        
        valueTF.setText ("" + String.format("%.2f", value));
    }
}

private class SubtractButtonHandler implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {
        double one, two, value;
        
        one = Double.parseDouble(oneTF.getText());
        two = Double.parseDouble(twoTF.getText());
        value = one - two;
        
        valueTF.setText ("" + String.format("%.2f", value));
    }
}


private class MultiplyButtonHandler implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {
        double one, two, value;
        
        one = Double.parseDouble(oneTF.getText());
        two = Double.parseDouble(twoTF.getText());
        value = one * two;
        
        valueTF.setText ("" + String.format("%.2f", value));
    }
}


private class DivideButtonHandler implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {
        double one, two, value;
        
        one = Double.parseDouble(oneTF.getText());
        two = Double.parseDouble(twoTF.getText());
        value = one / two;
        
        valueTF.setText ("" + String.format("%.2f", value));
    }
}

private class ExitButtonHandler implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {
        System.exit(0);
    }
}

    public static void main(String[] args)
    {
       Car interestProductObject = new Car(); 
    }
}
