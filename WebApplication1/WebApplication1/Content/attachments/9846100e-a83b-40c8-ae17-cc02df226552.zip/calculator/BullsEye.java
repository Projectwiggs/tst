
/**
 * Write a description of class BullsEye here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.awt.*;
import java.util.Random;
import javax.swing.*;
public class BullsEye extends JPanel
{
private Random randomNumbers = new Random();
private Color color1;
private Color color2;

public BullsEye()
{
    color1 = new Color(randomNumbers.nextInt(256),
    randomNumbers.nextInt(256), randomNumbers.nextInt(256));
    color2 = new Color(randomNumbers.nextInt(256),
    randomNumbers.nextInt(256), randomNumbers.nextInt(256));
}

public void paintComponent(Graphics g)
{
    super.paintComponent(g);
    
    int circles = 5;
    int radius = 25;
    
    int centerX = getWidth() / 2;
    int centerY = getHeight() / 2;
    
    for(int counter = circles; counter > 0; counter--)
    {
        if (counter %2 == 0)
        g.setColor(color1);
        else
        g.setColor(color2);
        
        g. fillOval(centerX - counter * radius, centerY - counter * radius, counter*radius * 2, counter * radius * 2);
    }
}
}